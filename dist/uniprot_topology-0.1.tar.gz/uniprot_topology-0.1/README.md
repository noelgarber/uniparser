# uniparser
 UniProt feature parser from .data file, available from UniProt's FTP server
